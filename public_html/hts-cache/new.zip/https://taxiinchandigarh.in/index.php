<!DOCTYPE html>
<html>
<head>
	<title>Guru Travels</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
	<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/all.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

</head>
<body>
	<header>
		<!-- <span class="logo">Shankar</span> Travels -->
		<div class="menu">
			<nav class="navbar navbar-expand-lg navbar-light bg-light">
					<a class="navbar-brand" href="index.php"><img src="assets/img/logo/stlogo.png" alt="logo"></a>
					<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarNavDropdown">
						<ul class="navbar-nav mx-auto">
							<li class="nav-item">
								<a class="nav-link" aria-current="page" href="index.php">HOME</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="about.php">ABOUT</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="carrental.php">CAR RENTAL</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="hotelbooking.php">HOTEL BOOKING</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="contact.php">CONTACT US</a>
							</li>
						</ul>
					</div>
			</nav>
		</div>
		<div class="slider1">
			<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
				<div class="carousel-indicators">
					<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
					<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
					<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
				</div>
				<div class="carousel-inner">
					<div class="carousel-item active">
						<img src="assets/img/slider/1.jpg" class="d-block w-100" alt="...">
						<div class="carousel-caption d-none d-md-block">
							<h1>TRAVEL TO DALHOUSIE, HIMACHAL PRADESH</h1>
						</div>
					</div>
					<div class="carousel-item">
						<img src="assets/img/slider/5.jpg" class="d-block w-100" alt="...">
						<div class="carousel-caption d-none d-md-block">
							<h1>TRAVEL TO VAISHNO DEVI</h1>
						</div>
					</div>
					<div class="carousel-item">
						<img src="assets/img/slider/2.jpg" class="d-block w-100" alt="...">
						<div class="carousel-caption d-none d-md-block">
							<h1>TRAVEL TO GOLDEN TEMPLE AMRITSAR</h1>
						</div>
					</div>
				</div>
				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
			</div>
		</div>
	</header>

	<section class="cars">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="text-center mt-5">
						<div class="feature">
							<h2 class="head2">Guru Travels Vehicles</h2>
							<p>Need a vehicle for your Outstation trip? We have Wide Range of vehicles.</p>
						</div>
					</div>
						<div class="swiper-container">
							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/1.png" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">DZIRE</h5>
											<!-- <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> -->
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=DZIRE">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/2.png" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">SWIFT / ETIOS LIVA</h5>
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=SWIFT / ETIOS LIVA">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/3.png" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">DZIRE ETIOS</h5>
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=DZIRE ETIOS">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/4.png" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">HONDA AMAZE</h5>
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=HONDA AMAZE">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/5.png" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">INNOVA CRYSTA</h5>
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=INNOVA CRYSTA">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/6.png" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">FORTUNER</h5>
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=FORTUNER">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/7.jpg" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">TEMPO TRAVELLER</h5>
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=TEMPO TRAVELLER">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/8.jpg" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">MINI BUS</h5>
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=MINI BUS">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="card">
										<img src="assets/img/cars/9.jpg" class="card-img-top" alt="...">
										<div class="card-body">
											<h5 class="card-title">DELUXE BUS 2X2</h5>
											<div class="text-center">
												<a class="btn btn-dark" href="taxi-book.php?a=DELUXE BUS 2X2">BOOK NOW</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- Add Pagination -->
							<!-- <div class="swiper-pagination"></div> -->
						</div>
				</div>
			</div>
		</div>
	</section>
	<section class="bg-img mt-5 text-center">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<h1 class="mb-4">We Have Taxi All Over The India</h1>
					<h2><i class="fas fa-car"></i> <i class="fas fa-car"></i> <i class="fas fa-car"></i> <i class="fas fa-car"></i> <i class="fas fa-car"></i> <i class="fas fa-car"></i> <i class="fas fa-car"></i> <i class="fas fa-car"></i> </h2>
					<p>We created our taxi to help you to find the most dependable and highest quality taxi services, anytime and anywhere. All our drivers are uniformed and fully licensed.</p>
					<button class="btn btn-dark mt-5">BOOK NOW</button>
				</div>
			</div>
		</div>
	</section>
				<section>
					<div class="container-fluid mt-5 mb-5">
						<div class="row">
							<div class="col-md-12">
								<div class="text-center mb-5 abt">
								<h2>ABOUT US</h2>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6 col-md-12 mb-5">
								<div class="abtus">
								<p>GURU TRAVELS make Cab booking in Chandigarh feasible. If you are looking for cabs in Chandigarh, Simply dial +91-7837904450 and a cab from GURU TRAVELS will arrive within a few minutes. Hire taxi for full day local Sideseens in Chandigarh. Cab service at reasonable prices. Book cab and taxi at lowest prices. Book Outstation tour packages for Dalhousie, Dharamshala, Shimla and Manali.</p>
								<p>GURU TRAVELS TAXI in chandigarh is one among the most preferred & trusted taxi service brand and fastest growing company in chandigarh. We understand the needs of businesses and have tailored our services to ensure that our clients receive a hassle-free rental experience.</p>
								<p>Our mission is to simplify outstation road travel anywhere in india. We know what you want when you book an outstation taxi. We are regularly upgrading our services to offer you comfortable travel with great value for money.</p>
								<p>We are happy to provide you best and lowest fare taxi service in chandigarh. We started GURU TRAVELS because we felt that there was a need to make outstation road travel in India 'delightful'.</p>
								</div>
							</div>
							<div class="col-lg-6 col-md-12">
								<div class="sec-img">
									<img src="assets/img/section/4.jpg" alt="car">
								</div>
							</div>
						</div>
					</div>
				</section>
				<section id="tour" class="mt-5">
				    <div class="container">
						<div class="row">
						    <div class=col-md-12>
						        <div class="tourhead">
						            <h2>Famous Tour Packages</h2>
						        </div>
						    </div>
						</div>    
						    <div class="row">
							<div class="col-md-4">
								<div class="text-center img-sec mb-5">
									<img src="assets/img/section/katra.jpg" alt="katra">
									<h5>Chandigarh to Katra</h5>
								</div>
							</div>
							<div class="col-md-4">
								<div class="text-center img-sec mb-5">
									<img src="assets/img/section/kashmir.jpg" alt="katra">
									<h5>Chandigarh to Srinagar</h5>
								</div>
							</div>
							<div class="col-md-4">
								<div class="text-center img-sec mb-5">
									<img src="assets/img/section/dalho.jpg" alt="katra">
									<h5>Chandigarh to Dalhousie</h5>
								</div>
							</div>
						</div>
					</div>	
				</section>
				<section id="review" class="mt-5">
				    <div class="container">
						<div class="row">
						    <div class=col-md-12>
						        <div class="tourhead">
						            <h2>OUR TAXI SERVICE REVIEW</h2>
						        </div>
						    </div>
						</div>    
						    <div class="row">
    							<div class="col-md-6">
    								<div class="text-center review-sec mb-5">
    									<img src="assets/img/section/male.png" alt="katra">
    									<p>"Excellent service by Guru Travels. My driver was waiting at Arrivals for me with a clear sign. He was very polite and friendly and drove me with no delay."</p>
    								</div>
    						
    							
    								<div class="text-center review-sec mb-5">
    									<img src="assets/img/section/male.png" alt="katra">
    									<p>"Great service. We arrived late at night and wanted to make sure we had a cab to our hotel. The driver of Guru Travels arrived on time and was courteous."</p>
    								</div>
    							</div>
    							<div class="col-md-6">
    								<div class="text-center review-sec mb-5">
    									<img src="assets/img/section/male.png" alt="katra">
    									<p>"Booked a Driver on Guru Travels website for an outstation travel to Katra. Was impressed that the driver allocated had good knowledge of the locality."</p>
    								</div>
    							
    							
    								<div class="text-center review-sec mb-5">
    									<img src="assets/img/section/male.png" alt="katra">
    									<p>"I am grateful to Guru Travels for sending a very efficient driver, He was well mannered, punctual and very professional in his work. Thank you for the same."</p>
    								</div>
    							</div>
						    </div>
					</div>	
				</section>
				<section class="contactinfo">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="text-center mb-5 mt-5">
									<h1>Have a Questions?</h1>
									<h4>If you have any comments, suggestions or questions, please do not hesitate to contact us.</h4>
								</div>
							</div>
						</div>
							<div class="row">
										<div class="col-md-6 mb-5">
								<div class="drivers">
									<h3 class="text-center"><i class="fas fa-car"></i> BOOK YOUR TAXI <i class="fas fa-car"></i></h3>
										<form action="formmail.php" method="post">
											<div class="form-group">
												<label for="exampleInputName">Name</label>
												<input type="text" class="form-control" name="Name" id="name" placeholder="Enter Full Name" required >
											</div>
											<div class="form-group">
												<label for="exampleInputEmail1">Email address</label>
												<input type="email" class="form-control" name="Email" id="email" placeholder="Enter Email Address" required >
											</div>
											<div class="form-group">
												<label for="exampleInputPhone">Mobile Number</label>
												<input type="text" class="form-control" name="Mobile" id="phone" placeholder="Enter Mobile Number" required >
											</div>
											<div class="form-group">
											    <label for="exampleFormControlTextarea1">Enter Your Message</label>
											    <textarea class="form-control" name="Message" id="message" rows="2" placeholder="Enter Your Query"></textarea>
										  </div>
											<button type="submit" class="btn btn-dark mt-3">Submit</button>
										</form>
								</div>
							</div>
								<div class="col-md-6">
									<div class="hand-img">
										<img src="assets/img/section/hand.png">
									</div>

								</div>
							</div>
						</div>
				</section>

				<section>
						<div class="container">
									<div class="row">
								<div class="col-md-4">
									<div class="text-center mt-5 border-rgt">
										<i class="fas fa-globe-asia mb-3"></i>
										<h4>OUR ADDRESS</h4>
										<p>550 Mill Pond Ave. Arlington, MA 02474</p>
									</div>
								</div>
								<div class="col-md-4 mt-5">
									<div class="text-center border-rgt">
										<i class="fas fa-mobile-alt mb-3"></i>
										<h4>OUR PHONES</h4>
										<p>+91-7837904450</p>
									</div>
								</div>
								<div class="col-md-4 mt-5">
									<div class="text-center">
										<i class="far fa-envelope mb-3"></i>
										<h4>OUR MAIL</h4>
										<p>Gurutravelschandighar@gmail.com</p>
									</div>
								</div>
								</div>
								</div>
				</section>
				<footer>
					<div class="container mt-5 mb-5 pt-5">
						<div class="row">
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> GURU TRAVELS</h3>
									<p class="p-3">GURU TRAVELS make Cab booking in Chandigarh feasible. If you are looking for cabs in Chandigarh, Simply dial +91-7837904450 and a cab from GURU TRAVELS will arrive within a few minutes. Hire taxi for full day local Sideseens in Chandigarh.</p>
									<button class="btn btn-dark"><a href="about.php">MORE</a></button>

								</div>
							</div>
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> Tour Packages</h3>
									<ul>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Katra</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Srinagar</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Dalhousie</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Manali</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Shimla</a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> Useful Links</h3>
									<ul>
										<li><a href="index.php"><i class="fas fa-car"></i> Home</a></li>
										<li><a href="about.php"><i class="fas fa-car"></i> About</a></li>
										<li><a href="carrental.php"><i class="fas fa-car"></i> Car Rental</a></li>
										<li><a href="hotelbooking.php"><i class="fas fa-car"></i> Hotel Booking</a></li>
										<li><a href="contact.php"><i class="fas fa-car"></i> Contact Us</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-12">
								<div class="text-center copy">
									<p>© 2021 GURU TRAVELS All Rights Reserved. Designed By <SPAN class="peer"><a href="https://www.peerinfotech.com/" target="=_blank">PEERINFOTECH</a></SPAN></p>
								</div>
							</div>
						</div>
					</div>
					<div class="mobile-button d-lg-none d-md-none d-sm-none">
                        <div class="container">
                        
                            <a href="whatsapp://send?phone=+917837904450&amp;text=Hi, I want to Book a Ride"><img src="assets/img/logo/whatsapp-icon.jpg" alt="Order On Whatsapp" style="width:30%;"></a>
                            
                            <a href="sms:+917837904450"> <img src="assets/img/logo/send-message.jpg" alt="Book a Ride" style="width:30%;"></a>
                            
                            <a href="tel:+917837904450"><img src="assets/img/logo/call-icon.jpg" alt="Book a Ride" style="width:30%;"></a>
                                           
                        </div>
                    </div>
				</footer>


				<script>
					var swiper = new Swiper('.swiper-container', {
						slidesPerView: '3',
						spaceBetween: 40,
						autoplay: {delay: 2000,},
						loop: true,
						pagination: {
							el: '.swiper-pagination',
							clickable: true,
						},

						 breakpoints: {
    // when window width is >= 320px
    320: {
      slidesPerView: 1,
      spaceBetween: 20
    },
    // when window width is >= 480px
    480: {
      slidesPerView: 2,
      spaceBetween: 30
    },
    // when window width is >= 640px
    640: {
      slidesPerView: 3,
      spaceBetween: 40
    }
  }
					});
				</script>




				<script src="assets/js/jquery-3.6.0.js"></script>
				<script src="assets/js/bootstrap.min.js"></script>
			</body>
			</html>