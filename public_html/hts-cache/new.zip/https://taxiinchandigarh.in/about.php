<!DOCTYPE html>
<html>
<head>
	<title>Guru Travels</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
	<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/all.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

</head>
<body>
	<header class="about-us">
		<!-- <span class="logo">Shankar</span> Travels -->
							<div class="menu">
						<nav class="navbar navbar-expand-lg navbar-light bg-light">
					<a class="navbar-brand" href="index.html"><img src="assets/img/logo/stlogo.png" alt="logo"></a>
					<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarNavDropdown">
						<ul class="navbar-nav mx-auto">
							<li class="nav-item">
								<a class="nav-link" aria-current="page" href="index.php">HOME</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="about.php">ABOUT</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="carrental.php">CAR RENTAL</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="hotelbooking.php">HOTEL BOOKING</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="contact.php">CONTACT US</a>
							</li>
						</ul>
					</div>
				
			</nav>
			</div>
	</header>
				<section>
					<div class="container-fluid mt-5 mb-5">
						<div class="row">
							<div class="col-md-12">
								<div class="text-center mb-5 abt">
								<h2>ABOUT US</h2>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6 col-md-12">
								<div class="abtus">
								<p>GURU TRAVELS make Cab booking in Chandigarh feasible. If you are looking for cabs in Chandigarh, Simply dial +91-7837904450 and a cab from GURU TRAVELS will arrive within a few minutes. Hire taxi for full day local Sideseens in Chandigarh. Cab service at reasonable prices. Book cab and taxi at lowest prices. Book Outstation tour packages for Dalhousie, Dharamshala, Shimla and Manali.</p>
								<p>GURU TRAVELS TAXI in chandigarh is one among the most preferred & trusted taxi service brand and fastest growing company in chandigarh. We understand the needs of businesses and have tailored our services to ensure that our clients receive a hassle-free rental experience.</p>
								<p>Our mission is to simplify outstation road travel anywhere in india. We know what you want when you book an outstation taxi. We are regularly upgrading our services to offer you comfortable travel with great value for money.</p>
								<p> We are happy to provide you best and lowest fare taxi service in chandigarh. We started GURU TRAVELS because we felt that there was a need to make outstation road travel in India 'delightful'.</p>
								</div>
							</div>
							<div class="col-lg-6 col-md-12">
								<div class="sec-img">
									<img src="assets/img/section/4.jpg" alt="car">
								</div>
							</div>
						</div>
					</div>
				</section>
				<section>
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mb-5">
								<h3>Tour Packages</h3>
								<p>Guru Travels offers a variety of tours for Groups and Individual tourists and has been able to mastermind tour packages with great deal of efficiency.</p>
								</div>
								<div class="mb-5">
								<h3>Online Hotel Booking</h3>
								<p>With our elaborated network of collaboration with the hotels in almost every part of the Indian subcontinent we provide our services of individual or group booking in any hotel of any category.</p>
							</div>
							<div class="mb-5">
								<h3>Airtickets Booking</h3>
								<p>We provide the services of air-ticketing facility to any parts of India and at any time with the Domestic and International Airlines at very lucrative discount.</p>
							</div>
							</div>
						</div>
						
					</div>
				</section>
			<footer>
					<div class="container mt-5 mb-5 pt-5">
						<div class="row">
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> GURU TRAVELS</h3>
									<p class="p-3">GURU TRAVELS make Cab booking in Chandigarh feasible. If you are looking for cabs in Chandigarh, Simply dial +91-7837904450 and a cab from GURU TRAVELS will arrive within a few minutes. Hire taxi for full day local Sideseens in Chandigarh.</p>
									<button class="btn btn-dark"><a href="about.php">MORE</a></button>

								</div>
							</div>
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> Tour Packages</h3>
									<ul>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Katra</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Srinagar</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Dalhousie</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Manali</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Shimla</a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> Useful Links</h3>
									<ul>
										<li><a href="index.php"><i class="fas fa-car"></i> Home</a></li>
										<li><a href="about.php"><i class="fas fa-car"></i> About</a></li>
										<li><a href="carrental.php"><i class="fas fa-car"></i> Car Rental</a></li>
										<li><a href="hotelbooking.php"><i class="fas fa-car"></i> Hotel Booking</a></li>
										<li><a href="contact.php"><i class="fas fa-car"></i> Contact Us</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-12">
								<div class="text-center copy">
									<p>© 2021 GURU TRAVELS All Rights Reserved. Designed By <SPAN class="peer"><a href="https://www.peerinfotech.com/" target="=_blank">PEERINFOTECH</a></SPAN></p>
								</div>
							</div>
						</div>
					</div>
					<div class="mobile-button d-lg-none d-md-none d-sm-none">
                        <div class="container">
                        
                            <a href="whatsapp://send?phone=+917837904450&amp;text=Hi, I want to Book a Ride"><img src="assets/img/logo/whatsapp-icon.jpg" alt="Order On Whatsapp" style="width:30%;"></a>
                            
                            <a href="sms:+917837904450"> <img src="assets/img/logo/send-message.jpg" alt="Book a Ride" style="width:30%;"></a>
                            
                            <a href="tel:+917837904450"><img src="assets/img/logo/call-icon.jpg" alt="Book a Ride" style="width:30%;"></a>
                                           
                        </div>
                    </div>
				</footer>


				<script>
					var swiper = new Swiper('.swiper-container', {
						slidesPerView: '3',
						spaceBetween: 40,
						autoplay: {delay: 2000,},
						loop: true,
						pagination: {
							el: '.swiper-pagination',
							clickable: true,
						},
					});
				</script>




				<script src="assets/js/jquery-3.6.0.js"></script>
				<script src="assets/js/bootstrap.min.js"></script>
			</body>
			</html>