<!DOCTYPE html>
<html>
<head>
	<title>Guru Travels</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
	<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/all.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

</head>
<body>
	<header class="about-us">
		<!-- <span class="logo">Shankar</span> Travels -->
					<div class="menu">
						<nav class="navbar navbar-expand-lg navbar-light bg-light">
								<a class="navbar-brand" href="index.html"><img src="assets/img/logo/stlogo.png" alt="logo"></a>
								<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
									<span class="navbar-toggler-icon"></span>
								</button>
								<div class="collapse navbar-collapse" id="navbarNavDropdown">
									<ul class="navbar-nav mx-auto">
										<li class="nav-item">
											<a class="nav-link" aria-current="page" href="index.php">HOME</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" href="about.php">ABOUT</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" href="carrental.php">CAR RENTAL</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" href="hotelbooking.php">HOTEL BOOKING</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" href="contact.php">CONTACT US</a>
										</li>
									</ul>
								</div>
						</nav>
					</div>
	</header>

	<section class="cars">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="text-center mt-5">
						<div class="feature">
							<h2 class="head2">CAR RENTAL</h2>
							<p class="mb-5">Need a vehicle for your Outstation trip? We have Wide Range of vehicles.</p>
						</div>
					</div>
					<div class="row card-row">
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/1.png" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">DZIRE</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=DZIRE">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/2.png" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">SWIFT / ETIOS LIVA</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=SWIFT / ETIOS LIVA">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/3.png" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">DZIRE ETIOS</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=DZIRE ETIOS">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/4.png" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">HONDA AMAZE</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=HONDA AMAZE">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/5.png" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">INNOVA CRYSTA</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=INNOVA CRYSTA">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/6.png" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">FORTUNER</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=FORTUNER">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/7.jpg" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">TEMPO TRAVELLER</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=TEMPO TRAVELLER">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/8.jpg" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">MINI BUS</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=MINI BUS">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card">
							<img src="assets/img/cars/9.jpg" class="card-img-top" alt="...">
							<div class="card-body">
								<h5 class="card-title">DELUXE BUS 2X2</h5>
								<div class="text-center">
									<a class="btn btn-dark" href="taxi-book.php?a=DELUXE BUS 2X2">BOOK NOW</a>
								</div>
							</div>
						</div>
					</div>
					</div>
				</div>
			</div>
		</div>
	</section>

					<footer>
					<div class="container mt-5 mb-5 pt-5">
						<div class="row">
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> GURU TRAVELS</h3>
									<p class="p-3">GURU TRAVELS make Cab booking in Chandigarh feasible. If you are looking for cabs in Chandigarh, Simply dial +91-7837904450 and a cab from GURU TRAVELS will arrive within a few minutes. Hire taxi for full day local Sideseens in Chandigarh.</p>
									<button class="btn btn-dark"><a href="about.php">MORE</a></button>

								</div>
							</div>
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> Tour Packages</h3>
									<ul>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Katra</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Srinagar</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Dalhousie</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Manali</a></li>
										<li><a href="#"><i class="fas fa-car"></i> Chandigarh to Shimla</a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="ftr-cntnt">
									<h3><i class="fas fa-car hdclr"></i> Useful Links</h3>
									<ul>
										<li><a href="index.php"><i class="fas fa-car"></i> Home</a></li>
										<li><a href="about.php"><i class="fas fa-car"></i> About</a></li>
										<li><a href="carrental.php"><i class="fas fa-car"></i> Car Rental</a></li>
										<li><a href="hotelbooking.php"><i class="fas fa-car"></i> Hotel Booking</a></li>
										<li><a href="contact.php"><i class="fas fa-car"></i> Contact Us</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-12">
								<div class="text-center copy">
									<p>© 2021 GURU TRAVELS All Rights Reserved. Designed By <SPAN class="peer"><a href="https://www.peerinfotech.com/" target="=_blank">PEERINFOTECH</a></SPAN></p>
								</div>
							</div>
						</div>
					</div>
					<div class="mobile-button d-lg-none d-md-none d-sm-none">
                        <div class="container">
                        
                            <a href="whatsapp://send?phone=+917837904450&amp;text=Hi, I want to Book a Ride"><img src="assets/img/logo/whatsapp-icon.jpg" alt="Order On Whatsapp" style="width:30%;"></a>
                            
                            <a href="sms:+917837904450"> <img src="assets/img/logo/send-message.jpg" alt="Book a Ride" style="width:30%;"></a>
                            
                            <a href="tel:+917837904450"><img src="assets/img/logo/call-icon.jpg" alt="Book a Ride" style="width:30%;"></a>
                                           
                        </div>
                    </div>
				</footer>

	<script>
		var swiper = new Swiper('.swiper-container', {
			slidesPerView: '3',
			spaceBetween: 40,
			autoplay: {delay: 2000,},
			loop: true,
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
		});
	</script>




	<script src="assets/js/jquery-3.6.0.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>